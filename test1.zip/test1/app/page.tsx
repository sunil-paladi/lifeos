import Header from "./components/common/Header";

export default function Home() {
  console.log("Header:", Header);

  return (
    <div>
      <pre>{typeof Header}</pre>
    </div>
  );
}